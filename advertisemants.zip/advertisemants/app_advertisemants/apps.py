from django.apps import AppConfig


class AppAdvertisemantsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_advertisemants'
    verbose_name = 'объявления'
