from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Advertisemant
from .forms import AdvertisemantForms
from django.urls import reverse


# Create your views here.
def index(request):
    advertisemants = Advertisemant.objects.all()
    context = {'advertisemants': advertisemants}
    return render(request, 'app_advertisemants/index.html', context)

def top_sellers(request):
    return render(request, 'app_advertisemants/top-sellers.html')

def advertisement_post(request):
    if request.method == 'POST':
        form = AdvertisemantForms(request.POST, request.FILES)
        if form.is_valid():
            advertisement = Advertisemant(**form.cleaned_data)
            advertisement.user = request.user
            advertisement.save()
            url = reverse('main-page')
            return redirect(url)
    
    else:
        form = AdvertisemantForms()
    context = {'form': form}
    return render (request, 'app_advertisemants/advertisement-post.html', context)

    